1. manifest.json and robots.txt required in dist folder.
2. .env required in main root.
